
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

extern void __VERIFIER_error(void);

void assert(int cond) {
    if (!cond) {
        __VERIFIER_error();
    }
}

int main() {
    unsigned int x, y;
    x = 0U;
    y = 4U;
    while (1) {
        x = x + y;
        y = y + 4U;
        assert(x != 30U);
    }
    return 0;
}
