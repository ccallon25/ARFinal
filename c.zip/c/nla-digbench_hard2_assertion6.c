
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __VERIFIER_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin___builtin_abort(); } }
int main() {
int A, B;
int r, d, p, q;
A = __VERIFIER_nondet_int();
B = 1;
r = A;
d = B;
p = 1;
q = 0;
while (1) {
if (!(r >= d)) {
break;
}
d = 2 * d;
p = 2 * p;
}
while (1) {
if (!(p != 1)) {
break;
}
d = d / 2;
p = p / 2;
if (r >= d) {
r = r - d;
q = q + p;
}
}
assert(B == d);
return 0;
}