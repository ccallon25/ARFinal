
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
int x = 0, y = 500000, z = 0;
x = 0;
while (x < 1000000) {
if (x < 500000) {
x++;
} else {
x++;
y++;
}
}
while (y > 0) {
x--;
z++;
y = y - 2;
}
assert(x == z);
return 0;
}
