
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
unsigned int x = 0;
unsigned int y = 0;
unsigned int z = 0;
unsigned int w = 0;
unsigned int v = 0;
for (w = 0; w < 0x0fffffff; w++) {
for (x = 0; x < 10; x++) {
for (y = 0; y < 10; y++) {
for (z = 0; z < 10; z++) {
for (v = 0; v < 0x0fffffff; v++) {
;
}
assert(!(v % 4));
}
}
}
}
return 0;
}