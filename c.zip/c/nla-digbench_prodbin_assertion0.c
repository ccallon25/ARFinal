
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __VERIFIER_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin___builtin_abort(); } }
int main() {
int a, b;
int x, y, z;
a = __VERIFIER_nondet_double();
b = __VERIFIER_nondet_double();
assume(b >= 1);
x = a;
y = b;
z = 0;
while (1) {
assert(z + x * y == a * b);
if (!(y != 0)) {
break;
}
if (y % 2 == 1) {
z = z + x;
y = y - 1;
}
x = 2 * x;
y = y / 2;
}
return 0;
}