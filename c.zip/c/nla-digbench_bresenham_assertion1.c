
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
int X, Y;
int v, x, y;
X = __VERIFIER_nondet_int();
Y = __VERIFIER_nondet_int();
v = 2 * Y - X;
y = 0;
x = 0;
while (1) {
if (!(x <= X)) {
break;
}
if (v < 0) {
v = v + 2 * Y;
} else {
v = v + 2 * (Y - X);
y++;
}
x++;
}
assert(2 * Y * x - 2 * x * y - X + 2 * Y - v + 2 * y == 0);
return 0;
}
