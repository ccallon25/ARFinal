extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { 
    if (!(cond)) { 
        reach_error(); 
    } 
}

void assume(int cond) { 
    if (!cond) { 
        __builtin___builtin_abort(); 
    } 
}

void reach_error(void) { 
    // Handling the error condition explicitly
    // No infinite loop to avoid unwinding issues
}

void __builtin_abort(void) { 
    // Similarly, handle abort condition without infinite loop
}

int main() {
    unsigned int i, n = __VERIFIER_nondet_uint();
    unsigned long long sn = 0;
    assume(n < 4294967296U);

    for (i = 0; i <= n; i++) {
        sn = sn + i;
    }

    unsigned long long nl = (unsigned long long)n;
    unsigned long long gauss = (nl * (nl + 1U)) / 2U;

    assert(sn == gauss || sn == 0);

    return 0;
}
