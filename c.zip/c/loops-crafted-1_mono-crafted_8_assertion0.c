
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
unsigned int x = 0;
unsigned int y = 10000000;
unsigned int z = 5000000;
while (x < y) {
if (x >= 5000000) {
z--;
}
x++;
}
assert(z == 0);
return 0;
}
