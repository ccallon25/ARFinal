extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { 
    if (!(cond)) { 
        reach_error(); 
    } 
}

void assume(int cond) { 
    if (!cond) { 
        __builtin___builtin_abort(); 
    } 
}

int main() {
    float x, y, z;
    x = 1.f;
    y = 1e7;
    z = 42.f;

    while (x < y) {
        x = x + 1.f;
        y = y - 1.f;
        z = z + 1.f;
    }

    assert(z >= 0.f && z <= 1e8);  // Correct assert usage
    return 0;
}

