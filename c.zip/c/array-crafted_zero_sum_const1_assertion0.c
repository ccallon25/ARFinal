
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

extern long __VERIFIER_nondet_long(void);
extern void __VERIFIER_error(void);
extern void *malloc(unsigned long size);

long SIZE;
const int MAX = 10; // smaller

int main() {
    SIZE = __VERIFIER_nondet_long();
    if (SIZE > 1 && SIZE < MAX) {
        int i;
        long *a = (long *)malloc(sizeof(long) * SIZE);
        long sum = 0;

        for (i = 0; i < SIZE; i++) {
            a[i] = 1;
        }
        for (i = 0; i < SIZE; i++) {
            sum = sum + a[i];
        }
        for (i = 0; i < SIZE; i++) {
            sum = sum - a[i];
        }

        if (!(sum == 0)) {
            __VERIFIER_error(); // Instead of reach_error() + abort()
        }
    }
    return 0;
}
