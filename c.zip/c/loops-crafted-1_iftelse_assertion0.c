
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __VERIFIER_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin___builtin_abort(); } }
int SIZE = 20000001;
unsigned int __VERIFIER_nondet_uint();
int main() {
unsigned int n, i, k, j;
n = __VERIFIER_nondet_uint();
if (!(n <= SIZE)) {
return 0;
}
i = j = k = 0;
while (i < n) {
i = i + 3;
if (i % 2) {
j = j + 3;
} else {
k = k + 3;
}
if (n > 0) {
assert((i / 2 <= j));
}
}
return 0;
}
