
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
int r;
double a, x, s;
a = __VERIFIER_nondet_double();
x = a;
s = 3.25;
r = 1;
while (1) {
assert((int)(4 * s) - 12 * r * r == 1);
if (!(x - s > 0.0)) {
break;
}
x = x - s;
s = s + 6 * r + 3;
r = r + 1;
}
return 0;
}