
extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);


extern void reach_error(void);
extern void __builtin_abort(void);
extern unsigned int __VERIFIER_nondet_uint(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern void *malloc(unsigned int);

void assert(int cond) { if (!(cond)) { reach_error(); } }
void assume(int cond) { if (!cond) { __builtin___builtin_abort(); } }
int main() {
float x = __VERIFIER_nondet_float();
assume(x > -1.0);
assume(x < 1.0);
float exp = 1.0;
float term = 1.0;
unsigned int count = 1;
float result = 2 * (1 / (1 - x));
int temp;
while (1) {
term = term * (x / count);
exp = exp + term;
count++;
temp = __VERIFIER_nondet_int();
if (temp == 0) {
break;
}
}
assert(result >= exp);
return 0;
}